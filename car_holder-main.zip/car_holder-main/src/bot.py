from datetime import date, timedelta
import logging
from typing import Any
from dateutil.relativedelta import relativedelta
import telebot
from telebot import types
from src.draw_month import draw_month
from pathlib import Path
import atexit
from src.dbpart.db_client import DbClient
from src.adapters.repository import UsersRepository, CitiesRepository, ReservationsRepository
from config import settings


today_date = date.today()
start_date = today_date - timedelta(today_date.weekday()) 

users_array = {}

car_holder = telebot.TeleBot(settings.bot_token)

db_client = DbClient(settings.pg_dsn)
db_client.connect()

users_repos = UsersRepository(db_client)
cities_repos = CitiesRepository(db_client)
reservs_repos = ReservationsRepository(db_client)


@car_holder.message_handler(commands=["start"])
def start_message(message):
    """Message to be sent to user when he uses /start command.

    Args:
        message (obj): represents messenge from user. Refer to Telegram API
    """
    car_holder.send_message(
        message.from_user.id,
        f"Hello 👋, this bot helps you to claim {settings.car_name} car! \n"
        "Use /help command to get started",
    )


@car_holder.message_handler(commands=["help"])
def help_message(message):
    """Message to be sent to user when he uses /help command.

    Args:
        message (obj): represents messenge from user. Refer to Telegram API
    """
    car_holder.send_message(
        message.from_user.id,
        f"Hello, this bot helps you to claim {settings.car_name} car! \n"
        "To get started you have to use /hello command in the chat. "
        "Bot will ask you to send your short pseudonym. That is necessary condition \n"
        "--------------------------------------------------------\n"
        "/printcal - shows you filled calendar. \n"
        "--------------------------------------------------------\n"
        "/addevent - proposes you dates when you can claim a car \n"
        "1) choose first day of claiming \n"
        "2) choose second day of claiming \n"
        "3) choose city when you willing to go\n"
        "--------------------------------------------------------\n"
        "/delevent - proposes you to delete one of your events\n",
    )


@car_holder.message_handler(commands=["hello"])
def hello_message(message):
    """When users uses /hello command bot ask user to write his (user) nickname that will be used in
    calendar drawing.

    Args:
        message (obj): represents messenge from user. Refer to Telegram API.
    """
    
    user = users_repos.get(message.from_user.id)
    if user:
        car_holder.send_message(
            message.chat.id, f"You already registred as {user.nick_name}! 🤷‍♀️"
        )
        return
    
    car_holder.send_message(
        message.from_user.id,
        "Let me know how can I call you? (Like a Misha) less the 6 symbols",
    )
    car_holder.register_next_step_handler(message, get_name)


def get_name(message):
    """Save username to db if its length less than 6 symbols

    Args:
        message (obj): represents messenge from user. Refer to Telegram API
    """

    if len(message.text) > 6:
        car_holder.send_message(
            message.chat.id, "You entered more than 5 symbols! 🤷‍♀️ \n" "Use /hello again"
        )
    else:
        users_repos.add(message.from_user.id, message.from_user.username, message.text)
        car_holder.send_message(message.chat.id, f"ThankYou, {message.text}!")


@car_holder.message_handler(commands=["printcal"])
def calendar_image(message):
    """Draw calendar and send it to user.

    Args:
        message (obj): represents messenge from user. Refer to Telegram API
    """
    picture_path = Path("src/calendar/picture01.png")
    user = users_repos.get(message.from_user.id)
    if not user:
        car_holder.send_message(message.chat.id, "You have no nickname, use /hello")
        return

    events = reservs_repos.get_by_end_date(user, start_date)

    draw_month(picture_path, events, users_repos, cities_repos)

    photo = open(picture_path, "rb")
    car_holder.send_photo(message.chat.id, photo)


@car_holder.message_handler(commands=["addevent"])
def add_event(message: Any) -> None:
    """Add event.
        Each event represent:
        first date - first day of holding car.
        second date - last day of holding car.

    Args:
        message (obj): represents messenge from user. Refer to Telegram API
    """

    user = users_repos.get(message.from_user.id)

    if not user:
        car_holder.send_message(message.chat.id, "You have no nickname, use /hello")
        return

    dates_keyboard = types.InlineKeyboardMarkup(row_width=8)

    dates_keyboard.add(
        types.InlineKeyboardButton("#", callback_data="None"),
        types.InlineKeyboardButton("Mo", callback_data="None"),
        types.InlineKeyboardButton("Tu", callback_data="None"),
        types.InlineKeyboardButton("We", callback_data="None"),
        types.InlineKeyboardButton("Th", callback_data="None"),
        types.InlineKeyboardButton("Fr", callback_data="None"),
        types.InlineKeyboardButton("Sa", callback_data="None"),
        types.InlineKeyboardButton("Su", callback_data="None"),
    )

    for i in range(0, 35, 7):
        day1 = start_date + relativedelta(days=i)
        day2 = start_date + relativedelta(days=i + 1)
        day3 = start_date + relativedelta(days=i + 2)
        day4 = start_date + relativedelta(days=i + 3)
        day5 = start_date + relativedelta(days=i + 4)
        day6 = start_date + relativedelta(days=i + 5)
        day7 = start_date + relativedelta(days=i + 6)
        weeknum = date(day1.year, day1.month, day1.day).isocalendar()[1]

        dates_keyboard.add(
            types.InlineKeyboardButton(f"W{weeknum}", callback_data="None"),
            types.InlineKeyboardButton(day1.day, callback_data=str(day1)),
            types.InlineKeyboardButton(day2.day, callback_data=str(day2)),
            types.InlineKeyboardButton(day3.day, callback_data=str(day3)),
            types.InlineKeyboardButton(day4.day, callback_data=str(day4)),
            types.InlineKeyboardButton(day5.day, callback_data=str(day5)),
            types.InlineKeyboardButton(day6.day, callback_data=str(day6)),
            types.InlineKeyboardButton(day7.day, callback_data=str(day7)),
        )

    car_holder.send_message(
        message.from_user.id,
        "Choose dates of reservation 👇",
        reply_markup=dates_keyboard,
    )


@car_holder.message_handler(commands=["delevent"])
def del_event(message):
    """Delete event.

    Args:
        message (obj): represents message from user. Refer to Telegram API
    """

    keyboard_deleting = types.InlineKeyboardMarkup()

    user = users_repos.get(message.from_user.id)

    if not user:
        car_holder.send_message(message.chat.id, "You have no nickname, use /hello")
        return

    reservations = reservs_repos.get_all_users_subscriptions(user)

    if not reservations:
        car_holder.send_message(
            message.from_user.id,
            "Hello, {message.from_user.first_name}, there are no dates for deleting 🙏",
        )
    else:
        for appointment in reservations:
            city = cities_repos.get_by_id(appointment.city_id)
            keyboard_deleting.add(
                types.InlineKeyboardButton(
                    text=f"#{city.city_name}   {appointment.start_date}   - {appointment.end_date}",
                    callback_data=f"DELETE_#{appointment.id}",
                )
            )

        car_holder.send_message(
            message.from_user.id,
            f"Hello, {message.from_user.first_name}, let's choose the range of dates to delete 👇",
            reply_markup=keyboard_deleting,
        )


@car_holder.callback_query_handler(
    func=lambda call: call.message.text == "Choose dates of reservation 👇"
    and not call.data == "None"
)
def callback_worker(call):
    """Draws cities keyboard. Each buttons returns callback string with start_date + final_date + city_name.

    Args:
        call (obj): callback object. Refer to Telegram API.
    """
    telegram_id = call.from_user.id

    if telegram_id not in list(users_array):
        users_array[telegram_id] = []

    users_array[telegram_id].append(call.data)

    dates_array = users_array[telegram_id]

    if len(dates_array) == 2:
        start_date = dates_array[0]
        final_date = dates_array[1]

        if start_date > final_date:
            start_date, final_date = final_date, start_date

        cities_keyboard = types.InlineKeyboardMarkup(row_width=2)

        city_array = cities_repos.list()

        cities = []

        for city in city_array:
            cities.append(types.InlineKeyboardButton(text=city.city_name, callback_data=f"{start_date} {final_date} {city.city_name}"))

        cities_keyboard.add(*cities, row_width=3)

        car_holder.edit_message_text(
            "And choose city 👇",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=cities_keyboard,
        )
        users_array[telegram_id] = []


@car_holder.callback_query_handler(
    func=lambda call: call.message.text == "And choose city 👇" and not call.data == "None"
)
def callback_to_db(call):
    """Get start_date, final_date and city from previous callbacks and make a record to database.

    Args:
        call (obj): callback object. Refer to Telegram API.
    """

    if call.data:
        start_date = call.data[0:10]
        final_date = call.data[11:21]
        city = call.data[22:]

        user = users_repos.get(call.from_user.id)
        city_ex = cities_repos.get_by_name(city)
        reservs_repos.add(user, city_ex, start_date, final_date)
        car_holder.edit_message_text(
            f"You are going to {city} from {start_date} to {final_date} 👍",
            call.message.chat.id,
            call.message.message_id,
        )


@car_holder.callback_query_handler(func=lambda call: call.data.startswith("DELETE_#"))
def callback_deleter(call):
    """Delete reservation regarding to callback data.

    Args:
        call (obj): callback object. Refer to Telegram API
    """
    record_id = int(call.data[8:])
    reservs_repos.delete(record_id)
    car_holder.edit_message_text(
        "Appointment was deleted! 👌",
        call.message.chat.id,
        call.message.message_id,
    )


@car_holder.message_handler(commands=["addcity"])
def add_city(message):
    """Add city to all cities list. Checks if user can perform that operations and starts next step handler."""
    if message.from_user.id not in settings.allowed_change_city:
        car_holder.send_message(
            message.from_user.id,
            "You are not allowed to perform that operation",
        )
        return
    
    car_holder.send_message(
        message.from_user.id,
        "Send me the city's full city name",
    )
    
    car_holder.register_next_step_handler(message, get_full_city_name)


def get_full_city_name(message):
    """Get full city name from user message. When ok - starts next step handler."""
    if not message.text:
        car_holder.send_message(
            message.from_user.id,
            "Blank message is not allowed there",
        )
    
    car_holder.send_message(
            message.from_user.id,
            "Well, seems to be ok! Now provide me short city name",
        )

    city_full_name = message.text

    car_holder.register_next_step_handler(message, get_short_name, city_full_name)


def get_short_name(message, city_full_name):
    """Get short city name. When ok - adds city to db."""
    if not message.text:
        car_holder.send_message(
            message.from_user.id,
            "Blank message is not allowed there",
        )
    city_short_name = message.text
    
    cities = cities_repos.list()
    
    for city in cities:
        if city.city_name == city_full_name or city.short_city_name == city_short_name:
            car_holder.send_message(
                message.from_user.id,
                f"{city_full_name} or {city_short_name} already exist!",
            )
            return

    cities_repos.add(city_full_name, city_short_name)
    car_holder.send_message(
        message.from_user.id,
        "Job is done",
    )


@car_holder.message_handler(commands=["delcity"])
def del_city(message):
    """Ask user for city that he is willing to delete"""
    if message.from_user.id not in settings.allowed_change_city:
        car_holder.send_message(
            message.from_user.id,
            "You are not allowed to perform that operation",
        )
        return
    
    car_holder.send_message(
        message.from_user.id,
        "Send me the city's full city name",
    )
    
    car_holder.register_next_step_handler(message, delete_city_from_db)

def delete_city_from_db(message):
    """Takes city name and perform db actions to delete city"""
    if not message.text:
        car_holder.send_message(
            message.from_user.id,
            "Blank message is not allowed there",
        )
    target_city = cities_repos.get_by_name(message.text)
    
    if target_city:
        cities_repos.delete(target_city.id)
        car_holder.send_message(
            message.from_user.id,
            "City was removed from the list",
        ) 


#@car_holder.message_handler(commands=["subscribe"])
def subscribing(message):

    tg_id = message.from_user.id

    with db_client.cursor() as curs:
        curs.execute(sql.check_user_exists, (tg_id,))
        user_exist = curs.fetchone()[0]

    if user_exist:
        with db_client.cursor() as curs:
            curs.execute(sql.change_subscription, {"tg_id": tg_id, "state": True})

        db_client.commit()
        car_holder.send_message(
            message.from_user.id,
            "You were sucessfully subscribed",
        )

    else:
        car_holder.send_message(
            message.from_user.id,
            "You haven't registered yet, print /hello to get started \n And then try again",
        )


#@car_holder.message_handler(commands=["unsubscribe"])
def unsubscribing(message):

    tg_id = message.from_user.id

    with db_client.cursor() as curs:
        curs.execute(sql.check_user_exists, (tg_id,))
        user_exist = curs.fetchone()[0]

    if user_exist:
        with db_client.cursor() as curs:
            curs.execute(sql.change_subscription, {"tg_id": tg_id, "state": False})

        db_client.commit()
        car_holder.send_message(
            message.from_user.id,
            "You were sucessfully unsubscribed",
        )

    else:
        car_holder.send_message(
            message.from_user.id,
            "You haven't registered yet, print /hello to get started \n And then try again",
        )


def main():
    logging.basicConfig(format="%(asctime)s - %(levelname)s - %(message)s", level=logging.INFO)
    car_holder.infinity_polling()


@atexit.register
def end():
    db_client.close()


if __name__ == "__main__":
    main()

