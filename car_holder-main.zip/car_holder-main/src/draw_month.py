import datetime
from PIL import Image, ImageDraw, ImageFont
from dateutil.relativedelta import relativedelta

just_start_date = datetime.date.fromisocalendar(
    datetime.datetime.today().year, datetime.date.today().isocalendar()[1], 1
)


def draw_month(namepic, events, users_repos, cities_repos):
    def grid_drawing(
        coordinate_x,
        coordinate_y,
        block_size_x=1.0,
        block_size_y=1.0,
        line_width=2,
        line_colour=(100, 100, 100,),
        fill_colour=None,
        multiplicator=1,
    ):

        coordinate = [
            (
                int(round(coordinate_x * grid_size_x * multiplicator)),
                int(round(coordinate_y * grid_size_y * multiplicator)),
            ),
            (
                (
                    int(
                        round(coordinate_x * grid_size_x * multiplicator)
                        + block_size_x * grid_size_x * multiplicator
                    )
                ),
                (
                    int(
                        round(coordinate_y * grid_size_y * multiplicator)
                        + block_size_y * grid_size_y * multiplicator
                    )
                ),
            ),
        ]

        draw.rectangle(
            coordinate, fill=fill_colour, outline=line_colour, width=line_width
        )

    def text_writer(
        text_to_write,
        coordinate_x,
        coordinate_y,
        font_size,
        font_style,
        font_colour,
        multiplicator=1,
        shift_y=0,
    ):

        draw.multiline_text(
            (
                int(
                    coordinate_x * grid_size_x * multiplicator
                    + (grid_size_x * multiplicator * 0.1)
                ),
                int(
                    coordinate_y * grid_size_y * multiplicator
                    + grid_size_y * multiplicator / 6 * shift_y
                ),
            ),
            text_to_write,
            fill=font_colour,
            font=ImageFont.truetype(font_style, size=int(font_size * multiplicator)),
        )

    def text_creator(iterday, events):

        return_data = ""

        if events:
            for appointment in events:
                if appointment.start_date <= iterday <= appointment.end_date:
                    
                    user_id = int(appointment.user_id)
                    user = users_repos.get_by_id(user_id)
                    user_nick = user.nick_name
                    
                    city_id = appointment.city_id
                    city = cities_repos.get_by_id(city_id)
                    city_id = city.short_city_name

                    return_data = (return_data + str(user_nick) + " - " + str(city_id + "\n"))

        return return_data

    image_size_x, cnt_grid_x = 1020, 85
    image_size_y, cnt_grid_y = 1100, 75
    multiplic = 10  # 1 - one block like one pixel, 10 - one block like 10 pixel

    grid_size_x, grid_size_y = (image_size_x / cnt_grid_x), (
        image_size_y / cnt_grid_y
    )  # Size of grid in pixel
    line_width = 2

    weekday_font_size = 4
    day_font_size = 4
    weeknum_font_size = 3
    text_font_size = 2

    today_month = datetime.datetime.today().month
    today_day = datetime.datetime.today().day

    WEEKDAY = ("empty", "MO", "TU", "WE", "TH", "FR", "SA", "SU")
    WEEKDAY_colour = (222, 222, 222,)
    weekday_font = r"src/calendar/verdana.ttf"

    WEEKNUM_colour = (222, 222, 222,)
    weeknum_font = r"src/calendar/verdana.ttf"

    DAYS_colour_workday = (222, 222, 222,)
    DAYS_colour_holliday = (200, 20, 20,)
    day_font = r"src/calendar/verdana.ttf"

    text_colour = (250, 250, 22,)
    text_font = r"src/calendar/AGENCYR.TTF"

    # create new blank picture
    img = Image.new("RGB", size=(image_size_x, image_size_y), color=(25, 25, 25))
    draw = ImageDraw.Draw(img)
    for i in range(1, len(WEEKDAY)):
        text_writer(
            WEEKDAY[i],
            i,
            0.5,
            weekday_font_size,
            weekday_font,
            WEEKDAY_colour,
            multiplicator=multiplic,
        )
        grid_drawing(i, 0.5, 1, 0.5, multiplicator=multiplic)

    row = 1

    current_year = datetime.datetime.today().year
    current_week = datetime.date.today().isocalendar()[1]
    WEEK_s = datetime.date.fromisocalendar(current_year, current_week, 1)
    start_date = WEEK_s + relativedelta(weeks=-1)

    for i in range(0, 42):

        day = start_date + relativedelta(days=i)
        weekday = day.isoweekday()

        if weekday == 6 or weekday == 7:
            fill = DAYS_colour_holliday
        else:
            fill = DAYS_colour_workday
        if (
            day.month == today_month
            or day.month == (datetime.datetime.today() + relativedelta(months=2)).month
        ):
            fill_colour = (5, 5, 5,)
            if day.day == today_day:
                fill_colour = (0, 60, 0,)
                line_width = 5
            else:
                line_width = 2
        else:
            fill_colour = (20, 20, 20,)
            line_width = 2

        grid_drawing(weekday, row, 1, 1, fill_colour=fill_colour, multiplicator=multiplic, line_width=line_width,)
        text_writer(
            str(day.day),
            weekday,
            row,
            day_font_size,
            day_font,
            fill,
            multiplicator=multiplic,
        )
        text_writer(
            text_creator(day, events),
            weekday,
            row,
            text_font_size,
            text_font,
            text_colour,
            multiplicator=multiplic,
            shift_y=2,
        )

        if weekday == 7:
            weeknum = datetime.date(day.year, day.month, day.day).isocalendar()[1]
            text_writer(
                str(weeknum),
                0,
                row,
                weeknum_font_size,
                weeknum_font,
                WEEKNUM_colour,
                multiplicator=multiplic,
            )
            row += 1
    img.save(namepic)
