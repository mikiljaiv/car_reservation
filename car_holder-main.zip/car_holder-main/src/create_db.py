import psycopg2
import os
from psycopg2 import Error
import urllib.parse as urlparse


def create_db():
    DATABASE_URL = os.getenv("DATABASE_URL")

    url = urlparse.urlparse(DATABASE_URL)

    # Connect to existing database
    connection = psycopg2.connect(
        user=url.username,
        password=url.password,
        host=url.hostname,
        port=url.port,
        database=url.path[1:],
    )

    connection.autocommit = True

    try:
        cursor = connection.cursor()

        check_db = "SELECT 1 FROM pg_catalog.pg_database WHERE datname = 'carholder'"

        cursor.execute(check_db)
        exists = cursor.fetchone()

        if not exists:
            create_db = """CREATE database carholder;"""
            cursor.execute(create_db)
            print("Database sucessfully created")

        else:
            print("Database already exists")

    except (Exception, Error) as error:
        print("Error while creating PostgreSQL", error)

    finally:
        if connection:
            cursor.close()
            connection.close()
            print("Connection with PostgreSQL been closed")


def main():
    create_db()


if __name__ == "__main__":
    main()
