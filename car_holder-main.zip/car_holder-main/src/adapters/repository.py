import abc
from datetime import datetime
from typing import List, Union
from src.models import City, Person, Reservation


class AbstractRepository(abc.ABC):
    @abc.abstractmethod
    def add(self):
        raise NotImplementedError

    def get(self):
        raise NotImplementedError


class UsersRepository(AbstractRepository):
    def __init__(self, db_client) -> None:
        self.db = db_client

    def add(self, tg_id: int, user_name: str, nick_name: str) -> None:
        with self.db.cursor() as cursor:
            cursor.execute(
                f"INSERT INTO users(tg_id, username, nickname) VALUES ({tg_id}, '{user_name}', '{nick_name}');"
            )
        self.db.commit()

    def get(self, reference: int) -> Union[Person, None]:
        with self.db.cursor() as cursor:
            cursor.execute(f"SELECT * FROM users WHERE tg_id={reference};")
            user = cursor.fetchone()
        if not user:
            return
        return Person(user[0], user[1], user[2], user[3], user[4])

    def get_by_id(self, reference: int) -> Union[Person, None]:
        with self.db.cursor() as cursor:
            cursor.execute(f"SELECT * FROM users WHERE id={reference};")
            user = cursor.fetchone()
        if not user:
            return
        return Person(user[0], user[1], user[2], user[3], user[4])

    def list(self) -> List[Person]:
        with self.db.cursor() as cursor:
            cursor.execute("SELECT * FROM users;")
            db_response = cursor.fetchall()
        return [Person(user[0], user[1], user[2], user[3], user[4]) for user in db_response]


class ReservationsRepository(AbstractRepository):
    def __init__(self, db_client) -> None:
        self.db = db_client

    def add(self, user: Person, city: City, start_date: datetime, end_date: datetime) -> None:
        with self.db.cursor() as cursor:
            cursor.execute(
                f"INSERT INTO reservations(user_id, city_id, start_date, end_date) VALUES ({user.id}, {city.id}, '{start_date}', '{end_date}');"
            )
        self.db.commit()

    def delete(self, id: int):
        with self.db.cursor() as cursor:
            cursor.execute(f"DELETE from reservations WHERE id = {id};")
        self.db.commit()

    def get_by_end_date(self, user: Person, date) -> List[Reservation]:
        with self.db.cursor() as cursor:
            cursor.execute(f"SELECT * from reservations WHERE end_date >= '{date}';")
            events = cursor.fetchall()
            if not events:
                return

            cities_repos = CitiesRepository(self.db)
            users_repos = UsersRepository(self.db)

            return [
                Reservation(
                    event[0],
                    users_repos.get_by_id(event[1]),
                    cities_repos.get_by_id(event[2]),
                    event[3],
                    event[4],
                )
                for event in events
            ]

    def get_all_users_subscriptions(self, user: Person) -> List[Reservation]:
        with self.db.cursor() as cursor:
            cursor.execute(f"SELECT * FROM reservations WHERE user_id={user.id};")
            subs = cursor.fetchall()

        if not subs:
            return

        cities_repos = CitiesRepository(self.db)

        return [
            Reservation(sub[0], user, cities_repos.get_by_id(sub[2]), sub[3], sub[4])
            for sub in subs
        ]


class CitiesRepository(AbstractRepository):
    def __init__(self, db_client) -> None:
        self.db = db_client

    def add(self, city_name: str, short_city_name: str) -> None:
        with self.db.cursor() as cursor:
            cursor.execute(
                f"INSERT INTO cities(city_name, short_city_name) VALUES ('{city_name}', '{short_city_name}');"
            )
        self.db.commit()

    def get_by_name(self, name: str) -> City:
        """Provide full city name to get City from db

        Args:
            name (str): full name of city

        Returns:
            City: instance of City class
        """
        with self.db.cursor() as cursor:
            cursor.execute(f"SELECT * FROM cities WHERE city_name='{name}'")
            city = cursor.fetchone()
        return City(city[0], city[1], city[2])

    def get_by_id(self, city_id: int) -> City:
        with self.db.cursor() as cursor:
            cursor.execute(f"SELECT * FROM cities WHERE id='{city_id}'")
            city = cursor.fetchone()
        return City(city[0], city[1], city[2])

    def list(self) -> List[City]:
        with self.db.cursor() as cursor:
            cursor.execute(f"SELECT * FROM cities;")
            cities = cursor.fetchall()
        if not cities:
            return
        return [City(city[0], city[1], city[2]) for city in cities]

    def delete(self, city_id) -> None:
        with self.db.cursor() as cursor:
            cursor.execute(f"DELETE from cities WHERE id = {city_id};")
        self.db.commit()
