from datetime import datetime
from dataclasses import dataclass


@dataclass
class Person:
    id: int
    telegram_id: int
    user_name: str
    nick_name: str
    created_at: datetime


@dataclass
class City:
    id: int
    city_name: str
    short_city_name: str = None


class Reservation:
    def __init__(self, id: int, user: Person, city: City, start_date: datetime, end_date: datetime, description = None):
        self.id = id
        self.user_id = user.id
        self.city_id = city.id
        self.start_date = start_date
        self.end_date = end_date
        self.description = description
