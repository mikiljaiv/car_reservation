import psycopg2
from psycopg2 import Error
import os
import urllib.parse as urlparse

cities = {
    "Svetogorsk": "Sve",
    "Segeja": "Seg",
    "Kondopoga": "Kon",
    "Kirishi": "Kir",
    "Shklov": "Shkl",
    "Goznak": "Gozn",
    "Vodokanal": "Vod",
    "SkladVerema": "Stor",
    "Tampere": "TMP",
    "Service": "SRV",
    "Sokol": "Sok",
    "Other": "OTH",
}


def fill_cities_db(cities):
    DATABASE_URL = os.getenv("DATABASE_URL")
    CAR_HOLDER_MODE = os.getenv("CAR_HOLDER_MODE")

    url = urlparse.urlparse(DATABASE_URL)
    connection = ''
    if CAR_HOLDER_MODE == "dev":
        url = urlparse.urlparse(DATABASE_URL)
        car_holder_bot = "/carholder"
        url = url._replace(path=car_holder_bot)

    try:
        connection = psycopg2.connect(
            user=url.username,
            password=url.password,
            host=url.hostname,
            port=url.port,
            database=url.path[1:],
        )

        cursor = connection.cursor()

        for key, value in cities.items():

            select_query = """
                        INSERT INTO cities (city_name, short_city_name)
                        VALUES (%s, %s)"""

            cursor.execute(select_query, (key, value))
            connection.commit()
        print("Values sucessfully inserted")

    except (Exception, Error) as error:
        print("Ошибка при работе с PostgreSQL", error)
    finally:
        if connection:
            cursor.close()
            connection.close()
            print("Соединение с PostgreSQL закрыто")


fill_cities_db(cities)
