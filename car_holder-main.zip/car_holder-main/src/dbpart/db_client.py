import urllib.parse as urlparse
import psycopg2


class DbClient:
    """Create connection with db and use its cursor"""

    def __init__(self, url):
        self.url = urlparse.urlparse(url)

    def connect(self):
        self.conn = psycopg2.connect(user=self.url.username,
                                     password=self.url.password,
                                     host=self.url.hostname,
                                     port=self.url.port,
                                     database=self.url.path[1:])

    def close(self):
        self.conn.close()

    def cursor(self):
        return self.conn.cursor()

    def commit(self):
        return self.conn.commit()
