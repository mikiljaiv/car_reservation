from yoyo import step

__depends__ = {}

steps = [
    step(
        """
        CREATE TABLE "users" (
        "id"         SERIAL,
        "tg_id"      INT UNIQUE,
        "username"   TEXT,
        "nickname"   TEXT UNIQUE NOT NULL,
        "created_at" DATE NOT NULL DEFAULT NOW(),
        PRIMARY KEY (id)
        );
        """
    ),
    step(
        """
        CREATE TABLE "cities" (
        "id"                SERIAL,
        "city_name"         TEXT,
        "short_city_name"   TEXT,
        PRIMARY KEY (id)
        );
        """
    ),
    step(
        """
        CREATE TABLE "reservations" (
        "id"            SERIAL,
        "user_id"       INT references users (id),
        "city_id"       INT references cities (id),
        "start_date"    DATE NOT NULL,
        "end_date"      DATE NOT NULL,
        "description"   TEXT,
        PRIMARY KEY (id)
        );
        """
    ),
]
