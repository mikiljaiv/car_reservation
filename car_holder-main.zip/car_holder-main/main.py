import src.bot as bot


def main():
    bot.main()


if __name__ == "__main__":
    main()
