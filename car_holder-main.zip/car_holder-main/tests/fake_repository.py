from typing import List
from src.models import Person
import random
from datetime import datetime


class FakeUsersRepository:
    
    rand_id = random.randint(10, 1000)
    current_date = datetime.now()
    
    def __init__(self, users: List[Person]) -> None:
        self._users = set(users)

    def add(self, telegram_id: int, user_name: str, nick_name: str, id: int = rand_id, date: datetime = current_date) -> None:
        user = Person(id, telegram_id, user_name, nick_name, date)
        self._users.add(user)

    def get(self, telegram_id) -> Person:
        return next(user for user in self._users if user.telegram_id == telegram_id)
    
    def get_by_id(self, id: int) -> Person:
        return next(user for user in self._users if user.id == id)

    def list(self) -> List[Person]:
        return list(self._users)
